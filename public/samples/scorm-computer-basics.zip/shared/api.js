// Finds the SCORM 1.2 API on a parent window (SCORM RTE API discovery).
window.findAPI = function () { var w = window, n = 0; while (w && n++ < 10) { if (w.API) return w.API; if (w.parent === w) break; w = w.parent; } return window.opener && window.opener.API || null; };
window.scormTime = function (ms) { var s = ms / 1000, h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = (s % 60).toFixed(2);
  return ("000" + h).slice(-4) + ":" + ("0" + m).slice(-2) + ":" + ("0" + sec).slice(-5); };